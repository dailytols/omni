
import React, { useContext, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { ThemeContext, Theme } from './contexts/ThemeContext';
import { TOOLS } from './constants';
import Dashboard from './pages/Dashboard';
import ToolPage from './pages/ToolPage';
import ThemeSwitcher from './components/ThemeSwitcher';
import { XIcon } from './components/Icons';

const LAST_VISITED_PAGE_KEY = 'omni-tools-last-page';

// Component to handle saving and restoring the last visited route
const RoutePersistence: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const isInitialLoad = useRef(true);

    // Save the current location to localStorage whenever it changes
    useEffect(() => {
        if (location.pathname !== '/') {
            localStorage.setItem(LAST_VISITED_PAGE_KEY, location.pathname);
        }
    }, [location.pathname]);

    // On initial load, check for a saved path and navigate to it
    useEffect(() => {
        if (isInitialLoad.current) {
            const lastVisitedPage = localStorage.getItem(LAST_VISITED_PAGE_KEY);
            if (lastVisitedPage && lastVisitedPage !== location.pathname) {
                navigate(lastVisitedPage, { replace: true });
            }
            isInitialLoad.current = false;
        }
    }, [navigate, location.pathname]);

    return null; // This component does not render anything
};


const AppLayout: React.FC = () => {
  const { theme } = useContext(ThemeContext);
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

  const themeClasses = {
    [Theme.LIGHT]: 'bg-gray-100 text-gray-800',
    [Theme.DARK]: 'bg-gray-900 text-gray-100',
    [Theme.GLASS]: 'bg-gray-900 text-gray-100',
  };

  const glassBgClass = theme === Theme.GLASS ? 'bg-cover bg-fixed bg-center' : '';

  return (
    <div
      className={`min-h-screen font-sans transition-colors duration-300 ${themeClasses[theme]} ${glassBgClass}`}
      style={theme === Theme.GLASS ? { backgroundImage: 'url(https://picsum.photos/1920/1080?blur=10)' } : {}}
    >
      {/* Ad Placeholders */}
      <div className="fixed top-0 left-0 right-0 h-16 bg-gray-300/50 dark:bg-gray-700/50 flex items-center justify-center text-gray-500 z-40">Top Banner Ad</div>
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 mb-4 w-11/12 max-w-2xl h-20 bg-gray-300/50 dark:bg-gray-700/50 flex items-center justify-center text-gray-500 z-40 rounded-lg">Bottom Floating Ad</div>
      <div className="fixed top-1/2 -translate-y-1/2 right-0 w-40 h-96 bg-gray-300/50 dark:bg-gray-700/50 items-center justify-center text-gray-500 z-40 hidden lg:flex">Side Banner Ad</div>

      <div className="flex pt-16">
        {/* Sidebar */}
        <aside className={`fixed lg:relative z-30 lg:z-auto inset-y-0 left-0 pt-16 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 w-64 transition-transform duration-300 ease-in-out 
          ${theme === Theme.GLASS ? 'bg-white/10 backdrop-blur-lg border-r border-white/20' : 'bg-white dark:bg-gray-800'}`}>
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Tools</h2>
              <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" aria-label="Close menu">
                  <XIcon className="w-6 h-6" />
              </button>
            </div>
            <nav>
              <ul>
                <li><Link to="/" className="block py-2 px-4 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" onClick={() => setIsSidebarOpen(false)}>Dashboard</Link></li>
                {TOOLS.map((tool) => (
                  <li key={tool.path}>
                    <Link to={tool.path} className="block py-2 px-4 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" onClick={() => setIsSidebarOpen(false)}>
                      {tool.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 lg:ml-0 lg:mr-40 min-h-screen">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <header className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="lg:hidden mr-4 p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-inset focus:ring-neon-blue" aria-label="Open menu">
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>
                </button>
                <h1 className="text-2xl md:text-3xl font-bold">
                  <Link to="/">Omni Tools</Link>
                </h1>
              </div>
              <ThemeSwitcher />
            </header>

            <div className="animate-fade-in">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                {TOOLS.map((tool) => (
                  <Route
                    key={tool.path}
                    path={tool.path}
                    element={<ToolPage title={tool.name} description={tool.description} component={tool.component} />}
                  />
                ))}
              </Routes>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};


const App: React.FC = () => {
  return (
    <HashRouter>
        <RoutePersistence />
        <AppLayout />
    </HashRouter>
  );
};

export default App;