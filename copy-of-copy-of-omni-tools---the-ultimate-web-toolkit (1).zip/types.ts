
import React from 'react';

export interface Tool {
  path: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  component: React.ComponentType;
  category: 'Calculators' | 'Text' | 'Utilities' | 'Device' | 'File';
}
