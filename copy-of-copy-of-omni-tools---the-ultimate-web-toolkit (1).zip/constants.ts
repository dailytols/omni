
import type { Tool } from './types';
import * as Tools from './components/tools';
import * as Icons from './components/Icons';

export const TOOLS: Tool[] = [
  // Basic Calculators
  { path: '/age-calculator', name: 'Age Calculator', description: 'Calculate age from date of birth.', icon: Icons.CakeIcon, component: Tools.AgeCalculator, category: 'Calculators' },
  { path: '/bmi-calculator', name: 'BMI Calculator', description: 'Calculate your Body Mass Index.', icon: Icons.ScaleIcon, component: Tools.BmiCalculator, category: 'Calculators' },
  { path: '/percentage-calculator', name: 'Percentage Calculator', description: 'Calculate percentages easily.', icon: Icons.PercentIcon, component: Tools.PercentageCalculator, category: 'Calculators' },
  { path: '/discount-calculator', name: 'Discount Calculator', description: 'Calculate final price after discount.', icon: Icons.TagIcon, component: Tools.DiscountCalculator, category: 'Calculators' },
  { path: '/gst-calculator', name: 'GST Calculator', description: 'Calculate Goods and Services Tax.', icon: Icons.ReceiptTaxIcon, component: Tools.GstCalculator, category: 'Calculators' },
  { path: '/simple-interest-calculator', name: 'Simple Interest Calculator', description: 'Calculate simple interest on a loan.', icon: Icons.CurrencyDollarIcon, component: Tools.SimpleInterestCalculator, category: 'Calculators' },
  { path: '/loan-emi-calculator', name: 'Loan EMI Calculator', description: 'Calculate your Equated Monthly Installment.', icon: Icons.HomeIcon, component: Tools.LoanEmiCalculator, category: 'Calculators' },

  // Text Tools
  { path: '/word-counter', name: 'Word & Character Counter', description: 'Count words and characters in your text.', icon: Icons.DocumentTextIcon, component: Tools.WordCounter, category: 'Text' },
  { path: '/remove-extra-spaces', name: 'Remove Extra Spaces', description: 'Clean up text by removing extra spaces.', icon: Icons.ScissorsIcon, component: Tools.RemoveExtraSpaces, category: 'Text' },
  { path: '/case-converter', name: 'Case Converter', description: 'Convert text to UPPERCASE or lowercase.', icon: Icons.SwitchHorizontalIcon, component: Tools.CaseConverter, category: 'Text' },
  { path: '/password-generator', name: 'Password Generator', description: 'Generate strong, random passwords.', icon: Icons.KeyIcon, component: Tools.PasswordGenerator, category: 'Text' },

  // Number & Utility Tools
  { path: '/qr-code-generator', name: 'QR Code Generator', description: 'Create QR codes from text or URLs.', icon: Icons.QrCodeIcon, component: Tools.QrCodeGenerator, category: 'Utilities' },
  { path: '/qr-code-scanner', name: 'QR Code Scanner', description: 'Scan QR codes using your webcam.', icon: Icons.CameraIcon, component: Tools.QrCodeScanner, category: 'Utilities' },
  { path: '/unit-converter', name: 'Unit Converter', description: 'Convert between various units of measurement.', icon: Icons.CalculatorIcon, component: Tools.UnitConverter, category: 'Utilities' },
  { path: '/random-number-generator', name: 'Random Number Generator', description: 'Generate random numbers in a range.', icon: Icons.HashtagIcon, component: Tools.RandomNumberGenerator, category: 'Utilities' },
  { path: '/stopwatch', name: 'Stopwatch', description: 'A simple and accurate stopwatch.', icon: Icons.ClockIcon, component: Tools.Stopwatch, category: 'Utilities' },
  { path: '/timer', name: 'Timer', description: 'Set a countdown timer.', icon: Icons.BellIcon, component: Tools.Timer, category: 'Utilities' },

  // Device Info Tools
  { path: '/what-is-my-ip', name: 'What is My IP?', description: 'Find your public IP address.', icon: Icons.GlobeAltIcon, component: Tools.IpDetector, category: 'Device' },
  { path: '/screen-resolution', name: 'Screen Resolution', description: 'Detect your screen resolution.', icon: Icons.DesktopComputerIcon, component: Tools.ScreenResolution, category: 'Device' },
  { path: '/device-info', name: 'Browser & Device Info', description: 'Get detailed information about your browser and device.', icon: Icons.InformationCircleIcon, component: Tools.DeviceInfo, category: 'Device' },

  // File Tools
  { path: '/image-compressor', name: 'Image Compressor', description: 'Compress JPEG/PNG images client-side.', icon: Icons.PhotographIcon, component: Tools.ImageCompressor, category: 'File' },
  { path: '/image-to-base64', name: 'Image to Base64', description: 'Convert images to Base64 strings.', icon: Icons.CodeIcon, component: Tools.ImageToBase64, category: 'File' },
];
