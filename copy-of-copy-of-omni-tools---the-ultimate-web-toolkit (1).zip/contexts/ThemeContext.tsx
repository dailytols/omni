
import React, { createContext, useState, useEffect, ReactNode } from 'react';

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
  GLASS = 'glass',
}

interface ThemeContextProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

export const ThemeContext = createContext<ThemeContextProps>({
  theme: Theme.DARK,
  setTheme: () => {},
});

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem('theme');
    return (savedTheme as Theme) || Theme.DARK;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove(Theme.LIGHT, Theme.DARK, 'glass-theme'); // 'glass-theme' is a marker, styling is applied via components

    if (theme === Theme.DARK) {
      root.classList.add(Theme.DARK);
    } else {
      root.classList.add(Theme.LIGHT);
    }

    localStorage.setItem('theme', theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};
