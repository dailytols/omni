
import React from 'react';
import { Link } from 'react-router-dom';
import { TOOLS } from '../constants';
import type { Tool } from '../types';
import ToolCard from '../components/ToolCard';

const Dashboard: React.FC = () => {
  const groupedTools = TOOLS.reduce((acc, tool) => {
    if (!acc[tool.category]) {
      acc[tool.category] = [];
    }
    acc[tool.category].push(tool);
    return acc;
  }, {} as Record<Tool['category'], Tool[]>);

  return (
    <div>
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold mb-2">Welcome to Omni Tools</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">Your one-stop solution for everyday web utilities.</p>
      </div>

      {Object.entries(groupedTools).map(([category, tools]) => (
        <div key={category} className="mb-12">
          <h2 className="text-2xl font-bold border-b-2 border-neon-blue/50 dark:border-neon-green/50 pb-2 mb-6">{category}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {tools.map((tool) => (
              <ToolCard key={tool.path} tool={tool} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default Dashboard;