
import React from 'react';
import { Link } from 'react-router-dom';
import ToolContainer from '../components/ToolContainer';
import { ArrowLeftIcon } from '../components/Icons';

interface ToolPageProps {
  title: string;
  description: string;
  component: React.ComponentType;
}

const ToolPage: React.FC<ToolPageProps> = ({ title, description, component: Component }) => {
  return (
    <div>
        <Link 
            to="/" 
            className="inline-flex items-center gap-2 mb-4 text-sm font-medium text-gray-600 dark:text-gray-400 hover:text-neon-blue dark:hover:text-neon-green transition-colors"
        >
            <ArrowLeftIcon className="w-4 h-4" />
            Back to Dashboard
        </Link>
        <ToolContainer>
            <h2 className="text-3xl font-bold mb-2">{title}</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{description}</p>
            <div className="mt-8">
                <Component />
            </div>
        </ToolContainer>
    </div>
  );
};

export default ToolPage;
