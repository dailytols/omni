
import React, { useContext } from 'react';
import { ThemeContext, Theme } from '../contexts/ThemeContext';
import { SunIcon, MoonIcon, SparklesIcon } from './Icons';

const ThemeSwitcher: React.FC = () => {
  const { theme, setTheme } = useContext(ThemeContext);

  const buttonStyle = (isActive: boolean) =>
    `p-2 rounded-full transition-colors duration-300 ${
      isActive
        ? 'bg-neon-blue text-white dark:bg-neon-green dark:text-gray-900'
        : 'hover:bg-gray-200 dark:hover:bg-gray-700'
    }`;

  return (
    <div className="flex items-center space-x-2 p-1 rounded-full bg-gray-200/50 dark:bg-gray-700/50">
      <button onClick={() => setTheme(Theme.LIGHT)} className={buttonStyle(theme === Theme.LIGHT)} aria-label="Light Theme">
        <SunIcon className="w-5 h-5" />
      </button>
      <button onClick={() => setTheme(Theme.DARK)} className={buttonStyle(theme === Theme.DARK)} aria-label="Dark Theme">
        <MoonIcon className="w-5 h-5" />
      </button>
      <button onClick={() => setTheme(Theme.GLASS)} className={buttonStyle(theme === Theme.GLASS)} aria-label="Glassmorphism Theme">
        <SparklesIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default ThemeSwitcher;
