
import React, { useContext, ReactNode } from 'react';
import { ThemeContext, Theme } from '../contexts/ThemeContext';

interface ToolContainerProps {
    children: ReactNode;
}

const ToolContainer: React.FC<ToolContainerProps> = ({ children }) => {
    const { theme } = useContext(ThemeContext);

    const themeClasses = {
        [Theme.LIGHT]: 'bg-white shadow-md',
        [Theme.DARK]: 'bg-gray-800',
        [Theme.GLASS]: 'bg-white/10 backdrop-blur-md border border-white/20',
    };

    return (
        <div className={`p-6 sm:p-8 rounded-2xl transition-colors duration-300 ${themeClasses[theme]}`}>
            {children}
        </div>
    );
};

export default ToolContainer;
