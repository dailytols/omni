
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import type { Tool } from '../types';
import { ThemeContext, Theme } from '../contexts/ThemeContext';

interface ToolCardProps {
  tool: Tool;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  const { theme } = useContext(ThemeContext);
  const Icon = tool.icon;
  
  const themeClasses = {
    [Theme.LIGHT]: 'bg-white hover:shadow-lg',
    [Theme.DARK]: 'bg-gray-800 hover:bg-gray-700/50',
    [Theme.GLASS]: 'bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20',
  };

  return (
    <Link to={tool.path} className={`block p-6 rounded-xl transition-all duration-300 transform hover:-translate-y-1 ${themeClasses[theme]}`}>
      <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-lg bg-neon-blue/20 text-neon-blue dark:bg-neon-green/20 dark:text-neon-green">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-lg font-bold mb-2">{tool.name}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-400">{tool.description}</p>
    </Link>
  );
};

export default ToolCard;
