
import React, { useState, useRef, useEffect } from 'react';

const Timer: React.FC = () => {
    const [hours, setHours] = useState('0');
    const [minutes, setMinutes] = useState('5');
    const [seconds, setSeconds] = useState('0');
    const [timeLeft, setTimeLeft] = useState(0);
    const [isActive, setIsActive] = useState(false);
    const intervalRef = useRef<number | null>(null);
    const audioRef = useRef<HTMLAudioElement | null>(null);

    useEffect(() => {
        if (isActive && timeLeft > 0) {
            intervalRef.current = window.setInterval(() => {
                setTimeLeft(prev => prev - 1);
            }, 1000);
        } else if (timeLeft === 0 && isActive) {
            setIsActive(false);
            if (intervalRef.current) clearInterval(intervalRef.current);
            audioRef.current?.play();
            alert("Time's up!");
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isActive, timeLeft]);
    
    const handleStart = () => {
        const totalSeconds = parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseInt(seconds);
        if (totalSeconds > 0) {
            setTimeLeft(totalSeconds);
            setIsActive(true);
        }
    };
    const handlePause = () => setIsActive(false);
    const handleReset = () => {
        setIsActive(false);
        setTimeLeft(0);
    };

    const formatTime = (time: number) => {
        const h = Math.floor(time / 3600);
        const m = Math.floor((time % 3600) / 60);
        const s = time % 60;
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    };

    return (
        <div className="text-center">
            {isActive || timeLeft > 0 ? (
                <div className="text-6xl font-mono p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg mb-6">
                    {formatTime(timeLeft)}
                </div>
            ) : (
                <div className="flex justify-center gap-4 mb-6">
                    <input type="number" value={hours} onChange={e => setHours(e.target.value)} className="input-time" min="0" />
                    <span className="text-4xl">:</span>
                    <input type="number" value={minutes} onChange={e => setMinutes(e.target.value)} className="input-time" min="0" max="59"/>
                    <span className="text-4xl">:</span>
                    <input type="number" value={seconds} onChange={e => setSeconds(e.target.value)} className="input-time" min="0" max="59"/>
                </div>
            )}
            <div className="flex justify-center gap-4">
                {!isActive && timeLeft === 0 && <button onClick={handleStart} className="btn-control bg-green-500">Start</button>}
                {isActive && <button onClick={handlePause} className="btn-control bg-yellow-500">Pause</button>}
                {!isActive && timeLeft > 0 && <button onClick={() => setIsActive(true)} className="btn-control bg-green-500">Resume</button>}
                <button onClick={handleReset} className="btn-control bg-gray-500">Reset</button>
            </div>
            <audio ref={audioRef} src="https://www.soundjay.com/buttons/beep-07a.mp3" preload="auto"></audio>
            <style>{`.input-time { width: 80px; text-align: center; font-size: 2.25rem; background-color: transparent; border: none; border-bottom: 2px solid; } .btn-control { color: white; font-weight: bold; padding: 0.75rem 1.5rem; border-radius: 0.5rem; }`}</style>
        </div>
    );
};

export default Timer;
