import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const CURRENCIES = [
  { symbol: '$', name: 'USD' },
  { symbol: '€', name: 'EUR' },
  { symbol: '£', name: 'GBP' },
  { symbol: '₹', name: 'INR' },
  { symbol: '¥', name: 'JPY' },
  { symbol: 'A$', name: 'AUD' },
  { symbol: 'C$', name: 'CAD' },
  { symbol: 'CHF', name: 'CHF' },
  { symbol: 'CN¥', name: 'CNY' },
  { symbol: 'HK$', name: 'HKD' },
  { symbol: 'NZ$', name: 'NZD' },
  { symbol: 'kr', name: 'SEK' },
  { symbol: '₩', name: 'KRW' },
  { symbol: 'S$', name: 'SGD' },
  { symbol: 'kr', name: 'NOK' },
  { symbol: 'Mex$', name: 'MXN' },
  { symbol: 'R$', name: 'BRL' },
  { symbol: 'R', name: 'ZAR' },
  { symbol: '₽', name: 'RUB' },
  { symbol: '₺', name: 'TRY' },
];

const LoanEmiCalculator: React.FC = () => {
    const [principal, setPrincipal] = useState('');
    const [rate, setRate] = useState('');
    const [tenure, setTenure] = useState('');
    const [currency, setCurrency] = useState('$');

    const result = useMemo(() => {
        const p = parseFloat(principal);
        const annualRate = parseFloat(rate);
        const t = parseFloat(tenure);

        if (isNaN(p) || isNaN(annualRate) || isNaN(t) || p <= 0 || annualRate <= 0 || t <= 0) return null;

        const r = annualRate / 12 / 100; // monthly rate
        const n = t * 12; // total number of months
        
        if (r === 0) { // Handle zero interest rate
            const emi = p / n;
            return { emi: emi.toFixed(2), totalInterest: '0.00', totalPayment: p.toFixed(2) };
        }

        const emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
        const totalPayment = emi * n;
        const totalInterest = totalPayment - p;

        return {
            emi: emi.toFixed(2),
            totalInterest: totalInterest.toFixed(2),
            totalPayment: totalPayment.toFixed(2)
        };
    }, [principal, rate, tenure]);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label className="block text-sm font-medium">Loan Amount</label>
                    <input type="number" value={principal} onChange={e => setPrincipal(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Annual Interest Rate (%)</label>
                    <input type="number" value={rate} onChange={e => setRate(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Loan Tenure (Years)</label>
                    <input type="number" value={tenure} onChange={e => setTenure(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Currency</label>
                    <select value={currency} onChange={e => setCurrency(e.target.value)} className="mt-1 block w-full select-field">
                        {CURRENCIES.map(c => <option key={c.name} value={c.symbol}>{c.name} ({c.symbol})</option>)}
                    </select>
                </div>
            </div>

            {result && (
                <div className="mt-6 space-y-2">
                    <ResultDisplay label="Monthly EMI" value={`${currency}${result.emi}`} />
                    <ResultDisplay label="Total Interest Payable" value={`${currency}${result.totalInterest}`} />
                    <ResultDisplay label="Total Payment (Principal + Interest)" value={`${currency}${result.totalPayment}`} />
                </div>
            )}
             <style>{`.input-field, .select-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
            :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
            `}</style>
        </div>
    );
};

export default LoanEmiCalculator;