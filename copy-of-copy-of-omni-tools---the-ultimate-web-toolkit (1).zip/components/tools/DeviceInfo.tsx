
import React, { useMemo } from 'react';

const DeviceInfo: React.FC = () => {
    const info = useMemo(() => {
        const ua = navigator.userAgent;
        return [
            { label: 'User Agent', value: ua },
            { label: 'Browser Name', value: navigator.appName },
            { label: 'Browser Version', value: navigator.appVersion },
            { label: 'Platform', value: navigator.platform },
            { label: 'Language', value: navigator.language },
            { label: 'Cookies Enabled', value: navigator.cookieEnabled ? 'Yes' : 'No' },
            { label: 'Online', value: navigator.onLine ? 'Yes' : 'No' },
        ];
    }, []);

    return (
        <div className="space-y-2">
            {info.map(({ label, value }) => (
                <div key={label} className="p-3 bg-gray-100 dark:bg-gray-700/50 rounded-lg flex flex-col sm:flex-row justify-between">
                    <span className="font-semibold text-gray-700 dark:text-gray-300">{label}:</span>
                    <span className="break-all text-gray-800 dark:text-gray-200">{value}</span>
                </div>
            ))}
        </div>
    );
};

export default DeviceInfo;
