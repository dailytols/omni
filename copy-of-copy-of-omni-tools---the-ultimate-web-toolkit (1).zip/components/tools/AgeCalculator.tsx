
import React, { useState, useCallback } from 'react';
import ResultDisplay from './common/ResultDisplay';

const AgeCalculator: React.FC = () => {
    const [dob, setDob] = useState('');
    const [age, setAge] = useState<{ years: number; months: number; days: number } | null>(null);

    const calculateAge = useCallback(() => {
        if (!dob) return;
        const birthDate = new Date(dob);
        const today = new Date();

        let years = today.getFullYear() - birthDate.getFullYear();
        let months = today.getMonth() - birthDate.getMonth();
        let days = today.getDate() - birthDate.getDate();

        if (days < 0) {
            months--;
            days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        }

        if (months < 0) {
            years--;
            months += 12;
        }

        setAge({ years, months, days });
    }, [dob]);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                <div>
                    <label htmlFor="dob" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date of Birth</label>
                    <input
                        type="date"
                        id="dob"
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-neon-blue focus:border-neon-blue sm:text-sm"
                    />
                </div>
                <button
                    onClick={calculateAge}
                    className="w-full md:w-auto bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity"
                >
                    Calculate Age
                </button>
            </div>
            {age && (
                <ResultDisplay
                    label="Your Age Is"
                    value={`${age.years} years, ${age.months} months, and ${age.days} days`}
                />
            )}
        </div>
    );
};

export default AgeCalculator;
