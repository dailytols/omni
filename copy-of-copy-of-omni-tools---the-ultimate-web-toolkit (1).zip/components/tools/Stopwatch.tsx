
import React, { useState, useRef, useCallback } from 'react';

const formatTime = (timeMs: number) => {
    const minutes = Math.floor(timeMs / 60000);
    const seconds = Math.floor((timeMs % 60000) / 1000);
    const milliseconds = Math.floor((timeMs % 1000) / 10);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(2, '0')}`;
};

const Stopwatch: React.FC = () => {
    const [time, setTime] = useState(0);
    const [lapTime, setLapTime] = useState(0);
    const [laps, setLaps] = useState<number[]>([]);
    const [isActive, setIsActive] = useState(false);
    const intervalRef = useRef<number | null>(null);
    const startTimeRef = useRef<number>(0);

    const handleStart = useCallback(() => {
        startTimeRef.current = Date.now() - time;
        setIsActive(true);
        intervalRef.current = window.setInterval(() => {
            const now = Date.now();
            setTime(now - startTimeRef.current);
            setLapTime(now - (laps.reduce((acc, curr) => acc + curr, 0) + startTimeRef.current));
        }, 10);
    }, [time, laps]);

    const handleStop = useCallback(() => {
        setIsActive(false);
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }
    }, []);
    
    const handleLap = useCallback(() => {
        if (!isActive) return;
        const currentLapTime = lapTime;
        setLaps(prev => [currentLapTime, ...prev]);
        setLapTime(0);
        startTimeRef.current = Date.now() - time; // Recalculate start time to keep overall time smooth
    }, [isActive, lapTime, time]);

    const handleReset = useCallback(() => {
        setIsActive(false);
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }
        setTime(0);
        setLapTime(0);
        setLaps([]);
    }, []);

    const totalLapTime = laps.reduce((a, b) => a + b, 0);

    return (
        <div className="flex flex-col items-center">
            <div className="w-full max-w-md text-center">
                <p className="text-xl text-gray-500 dark:text-gray-400 font-mono">
                    {formatTime(lapTime)}
                </p>
                <h1 className="text-7xl font-mono my-2 text-gray-800 dark:text-gray-200">
                    {formatTime(time)}
                </h1>

                <div className="flex justify-between items-center my-8">
                    <button 
                        onClick={isActive ? handleLap : handleReset} 
                        className="btn-control bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                        disabled={!isActive && time === 0}
                    >
                        {isActive ? 'Lap' : 'Reset'}
                    </button>
                    <button 
                        onClick={isActive ? handleStop : handleStart}
                        className={`btn-control ${isActive ? 'bg-red-500/80 text-red-50' : 'bg-green-500/80 text-green-50'}`}
                    >
                        {isActive ? 'Stop' : 'Start'}
                    </button>
                </div>

                {laps.length > 0 && (
                    <div className="w-full h-64 overflow-y-auto border-t border-gray-200 dark:border-gray-700">
                        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                            {laps.map((lap, index) => (
                                <li key={laps.length - index} className="flex justify-between p-4 text-lg font-mono">
                                    <span>Lap {laps.length - index}</span>
                                    <span>{formatTime(lap)}</span>
                                    <span>{formatTime(totalLapTime - laps.slice(index + 1).reduce((a,b)=> a+b, 0))}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
             <style>{`.btn-control { font-weight: 500; width: 100px; height: 100px; border-radius: 50%; font-size: 1.25rem; transition: background-color 0.2s; } .btn-control:disabled { opacity: 0.5; cursor: not-allowed; } `}</style>
        </div>
    );
};

export default Stopwatch;