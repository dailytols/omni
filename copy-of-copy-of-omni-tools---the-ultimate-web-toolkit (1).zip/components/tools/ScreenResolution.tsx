
import React, { useState, useEffect } from 'react';
import ResultDisplay from './common/ResultDisplay';

const ScreenResolution: React.FC = () => {
    const [resolution, setResolution] = useState({
        screenWidth: 0,
        screenHeight: 0,
        windowWidth: 0,
        windowHeight: 0
    });

    useEffect(() => {
        const updateResolution = () => {
            setResolution({
                screenWidth: window.screen.width,
                screenHeight: window.screen.height,
                windowWidth: window.innerWidth,
                windowHeight: window.innerHeight,
            });
        };
        
        updateResolution();
        window.addEventListener('resize', updateResolution);
        return () => window.removeEventListener('resize', updateResolution);
    }, []);

    return (
        <div>
            <ResultDisplay label="Screen Resolution" value={`${resolution.screenWidth} x ${resolution.screenHeight} pixels`} />
            <ResultDisplay label="Window Size (Viewport)" value={`${resolution.windowWidth} x ${resolution.windowHeight} pixels`} />
        </div>
    );
};

export default ScreenResolution;
