
import React, { useState } from 'react';

const ImageToBase64: React.FC = () => {
    const [base64, setBase64] = useState('');
    const [imageSrc, setImageSrc] = useState('');
    const [copied, setCopied] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setIsLoading(true);
            setImageSrc('');
            setBase64('');
            setCopied(false);

            const reader = new FileReader();
            reader.onload = (event) => {
                const result = event.target?.result as string;
                setImageSrc(result);
                setBase64(result);
                setIsLoading(false);
            };
            reader.onerror = () => {
                console.error("Failed to read file.");
                setIsLoading(false);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const copyToClipboard = () => {
        if (!base64) return;
        navigator.clipboard.writeText(base64);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div>
            <input type="file" accept="image/*" onChange={handleImageUpload} disabled={isLoading} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-neon-blue/20 file:text-neon-blue dark:file:bg-neon-green/20 dark:file:text-neon-green hover:file:bg-neon-blue/30 disabled:opacity-50" />
            
            {isLoading && (
                 <div className="mt-4 text-center p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg animate-pulse">
                    Loading image...
                </div>
            )}

            {!isLoading && imageSrc && (
                 <div className="mt-4 text-center">
                    <img src={imageSrc} alt="Preview" className="max-w-xs h-auto mx-auto rounded-lg" />
                </div>
            )}
            
            {!isLoading && base64 && (
                <div className="mt-6">
                    <textarea value={base64} readOnly className="w-full h-32 p-2 bg-gray-100 dark:bg-gray-900/50 border border-gray-300 dark:border-gray-600 rounded-md font-mono text-sm" />
                    <button onClick={copyToClipboard} className="mt-2 bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md">
                        {copied ? 'Copied!' : 'Copy to Clipboard'}
                    </button>
                </div>
            )}
        </div>
    );
};

export default ImageToBase64;
