
import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

type CalcMode = 'percentOf' | 'isWhatPercent' | 'percentChange';

const PercentageCalculator: React.FC = () => {
  const [mode, setMode] = useState<CalcMode>('percentOf');
  const [val1, setVal1] = useState('');
  const [val2, setVal2] = useState('');

  const result = useMemo(() => {
    const num1 = parseFloat(val1);
    const num2 = parseFloat(val2);

    if (isNaN(num1) || isNaN(num2)) return null;

    switch (mode) {
      case 'percentOf':
        return (num1 / 100 * num2).toFixed(2);
      case 'isWhatPercent':
        if (num2 === 0) return 'Cannot divide by zero';
        return ((num1 / num2) * 100).toFixed(2) + '%';
      case 'percentChange':
        if (num1 === 0) return 'Cannot calculate change from zero';
        const change = ((num2 - num1) / num1) * 100;
        return `${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
      default:
        return null;
    }
  }, [mode, val1, val2]);

  const renderInputs = () => {
    switch (mode) {
      case 'percentOf':
        return <><input type="number" value={val1} onChange={e => setVal1(e.target.value)} className="input-field" placeholder="Percent"/> % of <input type="number" value={val2} onChange={e => setVal2(e.target.value)} className="input-field" placeholder="Number"/></>;
      case 'isWhatPercent':
        return <><input type="number" value={val1} onChange={e => setVal1(e.target.value)} className="input-field" placeholder="Value"/> is what % of <input type="number" value={val2} onChange={e => setVal2(e.target.value)} className="input-field" placeholder="Total"/></>;
      case 'percentChange':
        return <>From <input type="number" value={val1} onChange={e => setVal1(e.target.value)} className="input-field" placeholder="Initial Value"/> to <input type="number" value={val2} onChange={e => setVal2(e.target.value)} className="input-field" placeholder="Final Value"/></>;
    }
  };
  
  const getButtonStyle = (m: CalcMode) => `px-3 py-2 text-sm rounded-md ${mode === m ? 'bg-neon-blue dark:bg-neon-green text-white dark:text-black' : 'bg-gray-200 dark:bg-gray-700'}`;

  return (
    <div>
        <style>{`.input-field { display: inline-block; width: 120px; text-align: center; margin: 0 8px; padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
        :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
        `}</style>
      <div className="flex flex-wrap gap-2 mb-4">
        <button onClick={() => setMode('percentOf')} className={getButtonStyle('percentOf')}>What is % of?</button>
        <button onClick={() => setMode('isWhatPercent')} className={getButtonStyle('isWhatPercent')}>X is what % of Y?</button>
        <button onClick={() => setMode('percentChange')} className={getButtonStyle('percentChange')}>Percentage Change</button>
      </div>

      <div className="flex items-center flex-wrap gap-2 text-lg">
        {renderInputs()}
      </div>

      {result && <ResultDisplay label="Result" value={result} />}
    </div>
  );
};

export default PercentageCalculator;
