
import React from 'react';

interface ResultDisplayProps {
  label: string;
  value: string | number | React.ReactNode;
  isLoading?: boolean;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ label, value, isLoading = false }) => {
  return (
    <div className="mt-6 p-4 rounded-lg bg-gray-100 dark:bg-gray-700/50">
      <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">{label}</h3>
      <div className="text-2xl font-bold text-neon-blue dark:text-neon-green mt-2 break-all">
        {isLoading ? (
          <div className="w-24 h-8 bg-gray-300 dark:bg-gray-600 rounded animate-pulse"></div>
        ) : (
          value
        )}
      </div>
    </div>
  );
};

export default ResultDisplay;
