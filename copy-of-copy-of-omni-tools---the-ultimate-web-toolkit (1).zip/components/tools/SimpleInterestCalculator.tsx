import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const CURRENCIES = [
  { symbol: '$', name: 'USD' },
  { symbol: '€', name: 'EUR' },
  { symbol: '£', name: 'GBP' },
  { symbol: '₹', name: 'INR' },
  { symbol: '¥', name: 'JPY' },
  { symbol: 'A$', name: 'AUD' },
  { symbol: 'C$', name: 'CAD' },
  { symbol: 'CHF', name: 'CHF' },
  { symbol: 'CN¥', name: 'CNY' },
  { symbol: 'HK$', name: 'HKD' },
  { symbol: 'NZ$', name: 'NZD' },
  { symbol: 'kr', name: 'SEK' },
  { symbol: '₩', name: 'KRW' },
  { symbol: 'S$', name: 'SGD' },
  { symbol: 'kr', name: 'NOK' },
  { symbol: 'Mex$', name: 'MXN' },
  { symbol: 'R$', name: 'BRL' },
  { symbol: 'R', name: 'ZAR' },
  { symbol: '₽', name: 'RUB' },
  { symbol: '₺', name: 'TRY' },
];

const SimpleInterestCalculator: React.FC = () => {
    const [principal, setPrincipal] = useState('');
    const [rate, setRate] = useState('');
    const [time, setTime] = useState('');
    const [currency, setCurrency] = useState('$');

    const result = useMemo(() => {
        const p = parseFloat(principal);
        const r = parseFloat(rate);
        const t = parseFloat(time);

        if (isNaN(p) || isNaN(r) || isNaN(t) || p < 0 || r < 0 || t < 0) return null;

        const interest = (p * r * t) / 100;
        const totalAmount = p + interest;

        return {
            interest: interest.toFixed(2),
            totalAmount: totalAmount.toFixed(2)
        };
    }, [principal, rate, time]);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label className="block text-sm font-medium">Principal Amount</label>
                    <input type="number" value={principal} onChange={e => setPrincipal(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Annual Rate (%)</label>
                    <input type="number" value={rate} onChange={e => setRate(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Time (Years)</label>
                    <input type="number" value={time} onChange={e => setTime(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Currency</label>
                    <select value={currency} onChange={e => setCurrency(e.target.value)} className="mt-1 block w-full select-field">
                        {CURRENCIES.map(c => <option key={c.name} value={c.symbol}>{c.name} ({c.symbol})</option>)}
                    </select>
                </div>
            </div>
            
            {result && (
                <div className="mt-6 space-y-2">
                    <ResultDisplay label="Total Interest" value={`${currency}${result.interest}`} />
                    <ResultDisplay label="Total Amount" value={`${currency}${result.totalAmount}`} />
                </div>
            )}
            <style>{`.input-field, .select-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
            :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
            `}</style>
        </div>
    );
};

export default SimpleInterestCalculator;