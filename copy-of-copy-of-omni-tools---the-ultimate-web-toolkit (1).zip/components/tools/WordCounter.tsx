import React, { useState, useMemo } from 'react';
import { ClockIcon, SpeakerWaveIcon } from '../Icons';

const WordCounter: React.FC = () => {
    const [text, setText] = useState('');
    const WORDS_PER_MINUTE_READING = 200;
    const WORDS_PER_MINUTE_SPEAKING = 150;

    const stats = useMemo(() => {
        const trimmedText = text.trim();
        const words = trimmedText ? trimmedText.match(/\S+/g) : [];
        const wordCount = words ? words.length : 0;
        const characters = text.length;
        const sentences = trimmedText.match(/[^.!?]+[.!?]+/g)?.length || (trimmedText ? 1 : 0);
        const paragraphs = trimmedText.split(/\n+/).filter(p => p.trim().length > 0).length;
        
        const readingTime = wordCount > 0 ? Math.ceil(wordCount / WORDS_PER_MINUTE_READING) : 0;
        const speakingTime = wordCount > 0 ? Math.ceil(wordCount / WORDS_PER_MINUTE_SPEAKING) : 0;

        return {
            words: wordCount,
            characters,
            sentences,
            paragraphs,
            readingTime,
            speakingTime,
        };
    }, [text]);

    return (
        <div>
            <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                className="w-full h-48 p-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-neon-blue focus:border-neon-blue"
                placeholder="Start typing here..."
            />
            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
                    <div className="text-2xl font-bold text-neon-blue dark:text-neon-green">{stats.words}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Words</div>
                </div>
                <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
                    <div className="text-2xl font-bold text-neon-blue dark:text-neon-green">{stats.characters}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Characters</div>
                </div>
                <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
                    <div className="text-2xl font-bold text-neon-blue dark:text-neon-green">{stats.sentences}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Sentences</div>
                </div>
                <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
                    <div className="text-2xl font-bold text-neon-blue dark:text-neon-green">{stats.paragraphs}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Paragraphs</div>
                </div>
            </div>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-center">
                 <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg flex items-center justify-center flex-col">
                    <ClockIcon className="w-8 h-8 mb-2 text-neon-blue dark:text-neon-green" />
                    <div className="text-2xl font-bold">{stats.readingTime} min</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Reading Time</div>
                </div>
                <div className="p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg flex items-center justify-center flex-col">
                    <SpeakerWaveIcon className="w-8 h-8 mb-2 text-neon-blue dark:text-neon-green" />
                    <div className="text-2xl font-bold">{stats.speakingTime} min</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Speaking Time</div>
                </div>
            </div>
        </div>
    );
};

export default WordCounter;
