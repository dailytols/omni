
import React, { useState } from 'react';
import ResultDisplay from './common/ResultDisplay';

const RandomNumberGenerator: React.FC = () => {
    const [min, setMin] = useState('1');
    const [max, setMax] = useState('100');
    const [result, setResult] = useState<number | null>(null);

    const generate = () => {
        const minNum = parseInt(min);
        const maxNum = parseInt(max);
        if (isNaN(minNum) || isNaN(maxNum) || minNum > maxNum) return;
        const rand = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;
        setResult(rand);
    };

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                    <label className="block text-sm font-medium">Min</label>
                    <input type="number" value={min} onChange={e => setMin(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Max</label>
                    <input type="number" value={max} onChange={e => setMax(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <button onClick={generate} className="bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md">Generate</button>
            </div>
            {result !== null && <ResultDisplay label="Random Number" value={result} />}
             <style>{`.input-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
            :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
            `}</style>
        </div>
    );
};

export default RandomNumberGenerator;
