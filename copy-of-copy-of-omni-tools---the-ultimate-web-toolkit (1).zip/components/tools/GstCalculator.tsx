import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const CURRENCIES = [
  { symbol: '$', name: 'USD' },
  { symbol: '€', name: 'EUR' },
  { symbol: '£', name: 'GBP' },
  { symbol: '₹', name: 'INR' },
  { symbol: '¥', name: 'JPY' },
  { symbol: 'A$', name: 'AUD' },
  { symbol: 'C$', name: 'CAD' },
  { symbol: 'CHF', name: 'CHF' },
  { symbol: 'CN¥', name: 'CNY' },
  { symbol: 'HK$', name: 'HKD' },
  { symbol: 'NZ$', name: 'NZD' },
  { symbol: 'kr', name: 'SEK' },
  { symbol: '₩', name: 'KRW' },
  { symbol: 'S$', name: 'SGD' },
  { symbol: 'kr', name: 'NOK' },
  { symbol: 'Mex$', name: 'MXN' },
  { symbol: 'R$', name: 'BRL' },
  { symbol: 'R', name: 'ZAR' },
  { symbol: '₽', name: 'RUB' },
  { symbol: '₺', name: 'TRY' },
];

const GstCalculator: React.FC = () => {
    const [amount, setAmount] = useState('');
    const [gstRate, setGstRate] = useState('18');
    const [type, setType] = useState<'add' | 'remove'>('add');
    const [currency, setCurrency] = useState('$');

    const result = useMemo(() => {
        const amt = parseFloat(amount);
        const rate = parseFloat(gstRate);
        if (isNaN(amt) || isNaN(rate) || amt < 0 || rate < 0) return null;

        let netAmount, gstAmount, totalAmount;
        if (type === 'add') {
            netAmount = amt;
            gstAmount = amt * (rate / 100);
            totalAmount = netAmount + gstAmount;
        } else { // remove
            totalAmount = amt;
            gstAmount = amt - (amt * (100 / (100 + rate)));
            netAmount = totalAmount - gstAmount;
        }

        return {
            netAmount: netAmount.toFixed(2),
            gstAmount: gstAmount.toFixed(2),
            totalAmount: totalAmount.toFixed(2)
        };
    }, [amount, gstRate, type]);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                <div>
                    <label className="block text-sm font-medium">Amount</label>
                    <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                <div>
                    <label className="block text-sm font-medium">GST Rate (%)</label>
                    <input type="number" value={gstRate} onChange={e => setGstRate(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
                 <div>
                    <label className="block text-sm font-medium">Currency</label>
                    <select value={currency} onChange={e => setCurrency(e.target.value)} className="mt-1 block w-full select-field">
                        {CURRENCIES.map(c => <option key={c.name} value={c.symbol}>{c.name} ({c.symbol})</option>)}
                    </select>
                </div>
            </div>
            <div className="flex gap-4 mt-4">
                <button onClick={() => setType('add')} className={`px-4 py-2 rounded-md ${type === 'add' ? 'bg-neon-blue dark:bg-neon-green text-white dark:text-black' : 'bg-gray-200 dark:bg-gray-700'}`}>Add GST</button>
                <button onClick={() => setType('remove')} className={`px-4 py-2 rounded-md ${type === 'remove' ? 'bg-neon-blue dark:bg-neon-green text-white dark:text-black' : 'bg-gray-200 dark:bg-gray-700'}`}>Remove GST</button>
            </div>

            {result && (
                <div className="mt-6 space-y-2">
                    <ResultDisplay label="Net Amount" value={`${currency}${result.netAmount}`} />
                    <ResultDisplay label="GST Amount" value={`${currency}${result.gstAmount}`} />
                    <ResultDisplay label="Total Amount" value={`${currency}${result.totalAmount}`} />
                </div>
            )}
             <style>{`.input-field, .select-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
            :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
            `}</style>
        </div>
    );
};

export default GstCalculator;