
import React, { useState, useEffect } from 'react';
import ResultDisplay from './common/ResultDisplay';

const IpDetector: React.FC = () => {
    const [ip, setIp] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchIp = async () => {
            setIsLoading(true);
            try {
                const response = await fetch('https://api.ipify.org?format=json');
                if (!response.ok) throw new Error('Failed to fetch');
                const data = await response.json();
                setIp(data.ip);
            } catch (error) {
                console.error("Error fetching IP:", error);
                setIp('Could not fetch IP address.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchIp();
    }, []);

    return (
        <div>
            <ResultDisplay label="Your Public IP Address" value={ip || ''} isLoading={isLoading} />
        </div>
    );
};

export default IpDetector;
