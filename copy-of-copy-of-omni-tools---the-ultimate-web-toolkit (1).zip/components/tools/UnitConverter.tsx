import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const UNITS = {
  length: {
    'Meters (m)': 1,
    'Kilometers (km)': 1000,
    'Centimeters (cm)': 0.01,
    'Inches (in)': 0.0254,
    'Feet (ft)': 0.3048,
    'Yards (yd)': 0.9144,
  },
  mass: {
    'Kilograms (kg)': 1,
    'Grams (g)': 0.001,
    'Pounds (lb)': 0.453592,
    'Ounces (oz)': 0.0283495,
  },
  temperature: {
    'Celsius (°C)': (c: number) => c,
    'Fahrenheit (°F)': (f: number) => (f - 32) * 5/9,
    'Kelvin (K)': (k: number) => k - 273.15,
  },
  area: {
    'Square Meters (m²)': 1,
    'Square Kilometers (km²)': 1000000,
    'Square Miles (mi²)': 2589990,
    'Acres (ac)': 4046.86,
    'Hectares (ha)': 10000,
  },
  volume: {
    'Liters (L)': 1,
    'Milliliters (mL)': 0.001,
    'Cubic Meters (m³)': 1000,
    'Gallons (US gal)': 3.78541,
    'Quarts (US qt)': 0.946353,
  },
  speed: {
    'Meters/sec (m/s)': 1,
    'Kilometers/hr (km/h)': 0.277778,
    'Miles/hr (mph)': 0.44704,
    'Knots (kn)': 0.514444,
  },
  data: {
    'Bytes (B)': 1,
    'Kilobytes (KB)': 1024,
    'Megabytes (MB)': 1048576,
    'Gigabytes (GB)': 1073741824,
    'Terabytes (TB)': 1099511627776,
  }
};

const UnitConverter: React.FC = () => {
    const [category, setCategory] = useState<keyof typeof UNITS>('length');
    const [fromUnit, setFromUnit] = useState<string>(Object.keys(UNITS.length)[0]);
    const [toUnit, setToUnit] = useState<string>(Object.keys(UNITS.length)[1]);
    const [value, setValue] = useState('1');

    const result = useMemo(() => {
        const val = parseFloat(value);
        if (isNaN(val)) return '';

        if (category === 'temperature') {
            const tempUnits = UNITS.temperature;
            const fromFunc = tempUnits[fromUnit as keyof typeof tempUnits];
            const toKey = Object.keys(tempUnits).find(k => k === toUnit) as keyof typeof tempUnits;

            const baseValue = fromFunc(val); // Convert to Celsius

            if (toKey === 'Celsius (°C)') return baseValue.toFixed(2);
            if (toKey === 'Fahrenheit (°F)') return (baseValue * 9/5 + 32).toFixed(2);
            if (toKey === 'Kelvin (K)') return (baseValue + 273.15).toFixed(2);
            return '';
        }

        const selectedUnits = UNITS[category];
        const baseValue = val * (selectedUnits[fromUnit as keyof typeof selectedUnits] as number);
        const convertedValue = baseValue / (selectedUnits[toUnit as keyof typeof selectedUnits] as number);
        return convertedValue.toPrecision(6);

    }, [category, fromUnit, toUnit, value]);
    
    const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newCategory = e.target.value as keyof typeof UNITS;
        setCategory(newCategory);
        const newUnits = Object.keys(UNITS[newCategory]);
        setFromUnit(newUnits[0]);
        setToUnit(newUnits.length > 1 ? newUnits[1] : newUnits[0]);
    };

    const currentUnits = Object.keys(UNITS[category]);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div>
                    <label className="block text-sm font-medium">Category</label>
                    <select value={category} onChange={handleCategoryChange} className="select-field">
                        {Object.keys(UNITS).map(cat => <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium">From</label>
                    <select value={fromUnit} onChange={e => setFromUnit(e.target.value)} className="select-field">
                        {currentUnits.map(unit => <option key={unit} value={unit}>{unit}</option>)}
                    </select>
                </div>
                 <div>
                    <label className="block text-sm font-medium">To</label>
                    <select value={toUnit} onChange={e => setToUnit(e.target.value)} className="select-field">
                        {currentUnits.map(unit => <option key={unit} value={unit}>{unit}</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium">Value</label>
                    <input type="number" value={value} onChange={e => setValue(e.target.value)} className="mt-1 block w-full input-field" />
                </div>
            </div>
            
            <ResultDisplay label="Converted Value" value={`${result} ${toUnit.match(/\(([^)]+)\)/)?.[1] || ''}`} />
            <style>{`.input-field, .select-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); width: 100%; margin-top: 4px; }
            :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
            `}</style>
        </div>
    );
};

export default UnitConverter;
