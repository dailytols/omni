import React, { useState, useCallback, useEffect } from 'react';
import ResultDisplay from './common/ResultDisplay';

const PasswordGenerator: React.FC = () => {
    const [length, setLength] = useState(16);
    const [includeUppercase, setIncludeUppercase] = useState(true);
    const [includeLowercase, setIncludeLowercase] = useState(true);
    const [includeNumbers, setIncludeNumbers] = useState(true);
    const [includeSymbols, setIncludeSymbols] = useState(true);
    const [password, setPassword] = useState('');
    const [strength, setStrength] = useState({ score: 0, label: '', color: 'bg-gray-200' });

    const calculateStrength = (pass: string) => {
        let score = 0;
        if (!pass) return { score: 0, label: '', color: 'bg-gray-200' };

        if (pass.length >= 8) score++;
        if (pass.length >= 12) score++;
        if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++;
        if (/\d/.test(pass)) score++;
        if (/[^A-Za-z0-9]/.test(pass)) score++;

        let label = 'Very Weak';
        let color = 'bg-red-500';
        if (score > 1) { label = 'Weak'; color = 'bg-orange-500'; }
        if (score > 2) { label = 'Medium'; color = 'bg-yellow-500'; }
        if (score > 3) { label = 'Strong'; color = 'bg-lime-500'; }
        if (score > 4) { label = 'Very Strong'; color = 'bg-green-500'; }
        
        return { score, label, color };
    };


    const generatePassword = useCallback(() => {
        const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const lower = 'abcdefghijklmnopqrstuvwxyz';
        const numbers = '0123456789';
        const symbols = '!@#$%^&*()_+~`|}{[]:;?><,./-=';

        let charset = '';
        if (includeUppercase) charset += upper;
        if (includeLowercase) charset += lower;
        if (includeNumbers) charset += numbers;
        if (includeSymbols) charset += symbols;

        if (charset === '') {
            setPassword('Please select at least one character type.');
            return;
        }

        let newPassword = '';
        for (let i = 0; i < length; i++) {
            newPassword += charset.charAt(Math.floor(Math.random() * charset.length));
        }
        setPassword(newPassword);
    }, [length, includeUppercase, includeLowercase, includeNumbers, includeSymbols]);

    useEffect(() => {
        setStrength(calculateStrength(password));
    }, [password]);
    
    const copyToClipboard = () => {
        if (password) navigator.clipboard.writeText(password);
    };

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium">Password Length: {length}</label>
                    <input type="range" min="8" max="64" value={length} onChange={e => setLength(parseInt(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <label className="flex items-center"><input type="checkbox" checked={includeUppercase} onChange={e => setIncludeUppercase(e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Uppercase (A-Z)</span></label>
                    <label className="flex items-center"><input type="checkbox" checked={includeLowercase} onChange={e => setIncludeLowercase(e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Lowercase (a-z)</span></label>
                    <label className="flex items-center"><input type="checkbox" checked={includeNumbers} onChange={e => setIncludeNumbers(e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Numbers (0-9)</span></label>
                    <label className="flex items-center"><input type="checkbox" checked={includeSymbols} onChange={e => setIncludeSymbols(e.target.checked)} className="h-4 w-4 rounded" /> <span className="ml-2">Symbols (!@#$)</span></label>
                </div>
            </div>
            <button onClick={generatePassword} className="mt-6 w-full bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md">Generate Password</button>
            {password && (
                <>
                    <div onClick={copyToClipboard} className="cursor-pointer group">
                        <ResultDisplay label="Your New Password (click to copy)" value={password} />
                        <p className="text-center text-sm mt-2 text-gray-500 group-hover:text-neon-blue dark:group-hover:text-neon-green">Click the box above to copy to clipboard</p>
                    </div>
                    <div className="mt-4">
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-medium">Password Strength:</span>
                            <span className={`text-sm font-bold text-gray-800 dark:text-gray-200`}>{strength.label}</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                            <div className={`${strength.color} h-2.5 rounded-full transition-all duration-300`} style={{ width: `${(strength.score / 5) * 100}%` }}></div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default PasswordGenerator;
