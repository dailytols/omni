
import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const BmiCalculator: React.FC = () => {
  const [units, setUnits] = useState<'metric' | 'imperial'>('metric');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [heightInches, setHeightInches] = useState('');

  const bmiResult = useMemo(() => {
    const w = parseFloat(weight);
    const h = parseFloat(height);

    if (!w || !h || w <= 0 || h <= 0) return null;

    let bmi;
    if (units === 'metric') {
      bmi = w / (h / 100) ** 2;
    } else {
      const hInchesTotal = h * 12 + (parseFloat(heightInches) || 0);
      bmi = (w / (hInchesTotal ** 2)) * 703;
    }

    if (isNaN(bmi) || !isFinite(bmi)) return null;
    
    let category = '';
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi < 24.9) category = 'Normal weight';
    else if (bmi < 29.9) category = 'Overweight';
    else category = 'Obesity';

    return { value: bmi.toFixed(2), category };
  }, [weight, height, heightInches, units]);

  return (
    <div>
      <div className="flex items-center space-x-4 mb-4">
        <label>Units:</label>
        <button onClick={() => setUnits('metric')} className={`px-4 py-2 rounded-md ${units === 'metric' ? 'bg-neon-blue dark:bg-neon-green text-white dark:text-black' : 'bg-gray-200 dark:bg-gray-700'}`}>Metric</button>
        <button onClick={() => setUnits('imperial')} className={`px-4 py-2 rounded-md ${units === 'imperial' ? 'bg-neon-blue dark:bg-neon-green text-white dark:text-black' : 'bg-gray-200 dark:bg-gray-700'}`}>Imperial</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium">{`Weight (${units === 'metric' ? 'kg' : 'lbs'})`}</label>
          <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
        </div>
        {units === 'metric' ? (
          <div>
            <label className="block text-sm font-medium">Height (cm)</label>
            <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-sm font-medium">Height (ft)</label>
              <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
            </div>
            <div>
              <label className="block text-sm font-medium">(in)</label>
              <input type="number" value={heightInches} onChange={e => setHeightInches(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
            </div>
          </div>
        )}
      </div>

      {bmiResult && (
        <ResultDisplay 
          label="Your BMI" 
          value={<>{bmiResult.value} <span className="text-lg text-gray-500 dark:text-gray-400">({bmiResult.category})</span></>}
        />
      )}
    </div>
  );
};

export default BmiCalculator;
