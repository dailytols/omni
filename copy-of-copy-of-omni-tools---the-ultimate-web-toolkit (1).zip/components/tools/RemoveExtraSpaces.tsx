
import React, { useState, useCallback } from 'react';

const RemoveExtraSpaces: React.FC = () => {
    const [text, setText] = useState('');

    const processText = useCallback(() => {
        const cleanedText = text.trim().replace(/\s+/g, ' ');
        setText(cleanedText);
    }, [text]);

    return (
        <div>
            <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                className="w-full h-48 p-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm"
                placeholder="Paste your text here..."
            />
            <div className="mt-4">
                <button onClick={processText} className="bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity">
                    Remove Extra Spaces
                </button>
            </div>
        </div>
    );
};

export default RemoveExtraSpaces;
