
import React, { useState, useRef } from 'react';

const ImageCompressor: React.FC = () => {
    const [originalImage, setOriginalImage] = useState<string | null>(null);
    const [compressedImage, setCompressedImage] = useState<string | null>(null);
    const [quality, setQuality] = useState(0.7);
    const [originalSize, setOriginalSize] = useState(0);
    const [compressedSize, setCompressedSize] = useState(0);
    const [isCompressing, setIsCompressing] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setOriginalSize(file.size);
            const reader = new FileReader();
            reader.onload = (event) => {
                setOriginalImage(event.target?.result as string);
                setCompressedImage(null);
                setCompressedSize(0);
            };
            reader.readAsDataURL(file);
        }
    };

    const compressImage = () => {
        if (!originalImage || isCompressing) return;
        
        setIsCompressing(true);
        setCompressedImage(null);
        setCompressedSize(0);

        const img = new Image();
        img.src = originalImage;
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(img, 0, 0);

            canvas.toBlob((blob) => {
                if (blob) {
                    setCompressedSize(blob.size);
                    setCompressedImage(URL.createObjectURL(blob));
                }
                setIsCompressing(false);
            }, 'image/jpeg', quality);
        };
        img.onerror = () => {
            console.error("Failed to load image for compression.");
            setIsCompressing(false);
        };
    };

    const sizeInKB = (bytes: number) => (bytes / 1024).toFixed(2);
    const savings = originalSize > 0 && compressedSize > 0 ? ((originalSize - compressedSize) / originalSize * 100).toFixed(2) : 0;

    return (
        <div>
            <input type="file" accept="image/jpeg, image/png" onChange={handleImageUpload} ref={fileInputRef} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-neon-blue/20 file:text-neon-blue dark:file:bg-neon-green/20 dark:file:text-neon-green hover:file:bg-neon-blue/30" />
            {originalImage && (
                <div className="mt-6">
                    <div className="mb-4">
                        <label>Quality: {Math.round(quality * 100)}%</label>
                        <input type="range" min="0.1" max="1" step="0.1" value={quality} onChange={e => setQuality(parseFloat(e.target.value))} className="w-full" />
                    </div>
                    <button onClick={compressImage} disabled={isCompressing} className="w-full bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md disabled:opacity-50 disabled:cursor-not-allowed">
                        {isCompressing ? 'Compressing...' : 'Compress'}
                    </button>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-center">
                        <div>
                            <h3 className="font-bold">Original Image</h3>
                            <img src={originalImage} alt="Original" className="max-w-full h-auto mx-auto rounded-lg mt-2" />
                            <p>Size: {sizeInKB(originalSize)} KB</p>
                        </div>
                        <div>
                            <h3 className="font-bold">Compressed Image</h3>
                            {isCompressing ? (
                                <div className="flex items-center justify-center h-48 bg-gray-200 dark:bg-gray-700 rounded-lg mt-2">
                                    <div className="animate-pulse">Processing...</div>
                                </div>
                            ) : compressedImage ? (
                                <>
                                    <img src={compressedImage} alt="Compressed" className="max-w-full h-auto mx-auto rounded-lg mt-2" />
                                    <p>Size: {sizeInKB(compressedSize)} KB</p>
                                    <p className="text-green-500 font-bold">Savings: {savings}%</p>
                                    <a href={compressedImage} download="compressed-image.jpg" className="mt-2 inline-block bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Download</a>
                                </>
                            ) : <div className="flex items-center justify-center h-48 bg-gray-200 dark:bg-gray-700 rounded-lg mt-2">Preview</div>}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ImageCompressor;
