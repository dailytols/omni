import React, { useState } from 'react';
import { QRCodeSVG as QRCode } from 'qrcode.react';

const QrCodeGenerator: React.FC = () => {
    const [text, setText] = useState('https://aistudio.google.com/');
    const [qrValue, setQrValue] = useState('https://aistudio.google.com/');
    const [fgColor, setFgColor] = useState('#000000');
    const [bgColor, setBgColor] = useState('#FFFFFF');

    const generateQr = () => {
        setQrValue(text);
    };

    return (
        <div>
            <div className="flex flex-col sm:flex-row gap-4 items-stretch">
                <input
                    type="text"
                    value={text}
                    onChange={e => setText(e.target.value)}
                    className="flex-grow p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md"
                    placeholder="Enter URL or text"
                />
                <button onClick={generateQr} className="bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md">
                    Generate
                </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                 <div>
                    <label htmlFor="fgColor" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Foreground Color</label>
                    <input type="color" id="fgColor" value={fgColor} onChange={e => setFgColor(e.target.value)} className="mt-1 w-full h-10 p-1 border border-gray-300 dark:border-gray-600 rounded-md cursor-pointer" />
                </div>
                <div>
                    <label htmlFor="bgColor" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Background Color</label>
                    <input type="color" id="bgColor" value={bgColor} onChange={e => setBgColor(e.target.value)} className="mt-1 w-full h-10 p-1 border border-gray-300 dark:border-gray-600 rounded-md cursor-pointer" />
                </div>
            </div>

            {qrValue && (
                <div className="mt-8 flex justify-center p-6 rounded-lg" style={{ backgroundColor: bgColor }}>
                    <QRCode value={qrValue} size={256} fgColor={fgColor} bgColor={bgColor} level="H" />
                </div>
            )}
        </div>
    );
};

export default QrCodeGenerator;
