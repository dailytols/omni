
import React, { useState } from 'react';
import { QrReader } from 'react-qr-reader';
import ResultDisplay from './common/ResultDisplay';

const QrCodeScanner: React.FC = () => {
    const [data, setData] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isScanning, setIsScanning] = useState(false);
    const [isLoading, setIsLoading] = useState(false); // For camera initialization

    const handleScan = (result: any, error: any) => {
        if (isLoading) {
            setIsLoading(false); // Camera is ready once we get the first callback
        }

        if (!!result) {
            setData(result?.text);
            setIsScanning(false);
        }

        if (!!error) {
            // Don't show 'No QR code found.' errors, as they are very frequent.
            if (error.name !== 'NotFoundException') {
                console.info(error);
                setError('An error occurred while scanning.');
            }
        }
    }

    const toggleScan = () => {
        if (isScanning) {
            setIsScanning(false);
            setIsLoading(false);
        } else {
            setData(null);
            setError(null);
            setIsScanning(true);
            setIsLoading(true);
        }
    };
    
    return (
        <div className="text-center">
            <button 
                onClick={toggleScan} 
                className="mb-4 bg-neon-blue dark:bg-neon-green text-white dark:text-gray-900 font-bold py-2 px-4 rounded-md"
            >
                {isScanning ? 'Stop Scanning' : 'Start Camera Scan'}
            </button>
            
            {isLoading && (
                <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-700/50 rounded-lg animate-pulse">
                    Initializing camera...
                </div>
            )}
            
            {isScanning && (
                <div className={`w-full max-w-sm mx-auto border-4 border-neon-blue dark:border-neon-green rounded-lg overflow-hidden mt-4 ${isLoading ? 'hidden' : 'block'}`}>
                    <QrReader
                        onResult={handleScan}
                        constraints={{ facingMode: 'environment' }}
                        containerStyle={{ width: '100%' }}
                    />
                </div>
            )}

            {error && <p className="text-red-500 mt-4">{error}</p>}
            {data && <ResultDisplay label="Scanned Result" value={data} />}
        </div>
    );
};

export default QrCodeScanner;
