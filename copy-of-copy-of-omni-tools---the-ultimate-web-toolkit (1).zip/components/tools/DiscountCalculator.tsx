import React, { useState, useMemo } from 'react';
import ResultDisplay from './common/ResultDisplay';

const CURRENCIES = [
  { symbol: '$', name: 'USD' },
  { symbol: '€', name: 'EUR' },
  { symbol: '£', name: 'GBP' },
  { symbol: '₹', name: 'INR' },
  { symbol: '¥', name: 'JPY' },
  { symbol: 'A$', name: 'AUD' },
  { symbol: 'C$', name: 'CAD' },
  { symbol: 'CHF', name: 'CHF' },
  { symbol: 'CN¥', name: 'CNY' },
  { symbol: 'HK$', name: 'HKD' },
  { symbol: 'NZ$', name: 'NZD' },
  { symbol: 'kr', name: 'SEK' },
  { symbol: '₩', name: 'KRW' },
  { symbol: 'S$', name: 'SGD' },
  { symbol: 'kr', name: 'NOK' },
  { symbol: 'Mex$', name: 'MXN' },
  { symbol: 'R$', name: 'BRL' },
  { symbol: 'R', name: 'ZAR' },
  { symbol: '₽', name: 'RUB' },
  { symbol: '₺', name: 'TRY' },
];

const DiscountCalculator: React.FC = () => {
  const [originalPrice, setOriginalPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [currency, setCurrency] = useState('$');

  const result = useMemo(() => {
    const price = parseFloat(originalPrice);
    const disc = parseFloat(discount);

    if (isNaN(price) || isNaN(disc) || price < 0 || disc < 0 || disc > 100) return null;

    const saved = price * (disc / 100);
    const finalPrice = price - saved;

    return {
      finalPrice: finalPrice.toFixed(2),
      saved: saved.toFixed(2),
    };
  }, [originalPrice, discount]);

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium">Original Price</label>
          <input type="number" value={originalPrice} onChange={e => setOriginalPrice(e.target.value)} className="mt-1 block w-full input-field" placeholder="e.g., 100" />
        </div>
        <div>
          <label className="block text-sm font-medium">Discount (%)</label>
          <input type="number" value={discount} onChange={e => setDiscount(e.target.value)} className="mt-1 block w-full input-field" placeholder="e.g., 25" />
        </div>
        <div>
          <label className="block text-sm font-medium">Currency</label>
          <select value={currency} onChange={e => setCurrency(e.target.value)} className="mt-1 block w-full select-field">
            {CURRENCIES.map(c => <option key={c.name} value={c.symbol}>{c.name} ({c.symbol})</option>)}
          </select>
        </div>
      </div>

      {result && (
        <>
            <ResultDisplay label="Final Price" value={`${currency}${result.finalPrice}`} />
            <div className="mt-2 p-4 rounded-lg bg-green-100 dark:bg-green-900/50">
                <p className="text-green-800 dark:text-green-300">You saved {currency}{result.saved}</p>
            </div>
        </>
      )}
      <style>{`.input-field, .select-field { padding: 8px; border-radius: 6px; background-color: var(--bg-color); border: 1px solid var(--border-color); }
      :root { --bg-color: #fff; --border-color: #d1d5db; } .dark { --bg-color: #374151; --border-color: #4b5563; }
      `}</style>
    </div>
  );
};

export default DiscountCalculator;