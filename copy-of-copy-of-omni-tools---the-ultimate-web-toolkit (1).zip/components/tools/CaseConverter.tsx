import React, { useState } from 'react';
import { ClipboardDocumentIcon } from '../Icons';

const CaseConverter: React.FC = () => {
    const [text, setText] = useState('');
    const [copied, setCopied] = useState(false);

    // Helper to get words from various formats
    const getWords = (str: string) => {
        return str
            .replace(/([a-z])([A-Z])/g, '$1 $2') // split camelCase
            .replace(/[_-]/g, ' ') // split snake_case and kebab-case
            .toLowerCase()
            .split(/\s+/)
            .filter(Boolean);
    };

    const toUpperCase = () => setText(text.toUpperCase());
    const toLowerCase = () => setText(text.toLowerCase());
    const toSentenceCase = () => {
        setText(text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, c => c.toUpperCase()));
    };
    const toTitleCase = () => {
        setText(text.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '));
    };
     const toInverseCase = () => {
        setText(text.split('').map(c => c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase()).join(''));
    };
    const toAlternatingCase = () => {
        setText(text.split('').map((c, i) => i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()).join(''));
    };
    // New Advanced Functions
    const toCamelCase = () => {
        const words = getWords(text);
        setText(words.map((word, index) => 
            index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)
        ).join(''));
    };
    const toPascalCase = () => {
        const words = getWords(text);
        setText(words.map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(''));
    };
    const toSnakeCase = () => {
        const words = getWords(text);
        setText(words.join('_'));
    };
    const toKebabCase = () => {
        const words = getWords(text);
        setText(words.join('-'));
    };

    const clearText = () => setText('');

    const copyToClipboard = () => {
        if (!text) return;
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };


    return (
        <div>
            <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                className="w-full h-48 p-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm"
                placeholder="Type or paste your text here..."
            />
            <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={toUpperCase} className="btn btn-convert">UPPER CASE</button>
                <button onClick={toLowerCase} className="btn btn-convert">lower case</button>
                <button onClick={toSentenceCase} className="btn btn-convert">Sentence case</button>
                <button onClick={toTitleCase} className="btn btn-convert">Title Case</button>
                <button onClick={toInverseCase} className="btn btn-convert">iNVERSE cASE</button>
                <button onClick={toAlternatingCase} className="btn btn-convert">aLtErNaTiNg cAsE</button>
                <button onClick={toCamelCase} className="btn btn-convert">camelCase</button>
                <button onClick={toPascalCase} className="btn btn-convert">PascalCase</button>
                <button onClick={toSnakeCase} className="btn btn-convert">snake_case</button>
                <button onClick={toKebabCase} className="btn btn-convert">kebab-case</button>
                
                <button onClick={copyToClipboard} className="btn btn-action flex items-center gap-2">
                    <ClipboardDocumentIcon className="w-5 h-5" />
                    {copied ? 'Copied!' : 'Copy'}
                </button>
                <button onClick={clearText} className="btn btn-danger">Clear</button>
            </div>
            <style>{`
                .btn { font-weight: bold; padding: 0.5rem 1rem; border-radius: 0.375rem; transition: all 0.2s ease-in-out; }
                .btn:hover { transform: translateY(-1px); }
                .btn-convert { background-color: #00BFFF; color: white; }
                .btn-convert:hover { opacity: 0.9; }
                .dark .btn-convert { background-color: #39FF14; color: #1f2937; }
                .btn-action { background-color: #6b7280; color: white; }
                .btn-action:hover { background-color: #4b5563; }
                .btn-danger { background-color: #ef4444; color: white; }
                .btn-danger:hover { background-color: #dc2626; }
            `}</style>
        </div>
    );
};

export default CaseConverter;